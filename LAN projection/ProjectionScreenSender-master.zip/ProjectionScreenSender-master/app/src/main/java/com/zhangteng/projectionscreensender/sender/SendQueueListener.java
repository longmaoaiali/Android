package com.zhangteng.projectionscreensender.sender;

/**
 * Created by swing on 2018/8/21.
 */
public interface SendQueueListener {
    void good();
    void bad();
}
