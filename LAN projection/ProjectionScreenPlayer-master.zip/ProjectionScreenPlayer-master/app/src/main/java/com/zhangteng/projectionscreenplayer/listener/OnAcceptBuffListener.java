package com.zhangteng.projectionscreenplayer.listener;


import com.zhangteng.projectionscreenplayer.entity.Frame;

public interface OnAcceptBuffListener {
    void acceptBuff(Frame frame);
}
